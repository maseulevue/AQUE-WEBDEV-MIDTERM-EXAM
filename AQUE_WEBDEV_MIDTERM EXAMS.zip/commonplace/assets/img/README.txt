Local visual assets only. mark.svg is the Commonplace logo. No remote image requests are used.
