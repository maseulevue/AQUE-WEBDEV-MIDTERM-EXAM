# Commonplace

A lightweight, frontend-only social media prototype about privacy, expression, and keeping the internet human.

**Developer:** Hannah Dennisse Aque  
**Stack:** HTML, CSS, Vanilla JavaScript  
**No frameworks, backend, database, API calls, external fonts, or analytics scripts.**

## Project structure

```text
commonplace/
├── index.html
├── pages/
│   ├── login.html
│   ├── signup.html
│   ├── profile.html
│   ├── privacy.html
│   └── about.html
├── src/
│   ├── css/
│   │   └── style.css
│   └── js/
│       └── main.js
└── assets/
    └── img/
        └── mark.svg
```

## Run it

1. Extract the ZIP file.
2. Open `index.html` in a browser. A small local static server is also fine, but no build step is required.
3. Try creating a demo profile, writing a post, liking it, editing the profile, and clearing local data.

Some browsers restrict storage when files are opened directly with `file://`. If a feature does not persist, open the folder with a simple local static server. The project still uses only the files in this repository.

## What works

- **Main feed:** sample community notes, a composer, chronological ordering, a feed filter, local likes, and delete controls for posts created in the current browser.
- **Signup and login:** demo-only forms that remember a display name and username. The password is never saved or checked.
- **Profile:** display name and bio can be edited. Your own posts appear here.
- **Privacy room:** plain-language explanation of storage and a control to clear the demo profile, posts, and session.
- **About us:** project intent, limitations, and developer credit.
- **Responsive layout:** navigation and cards adapt to smaller screens.
- **Accessibility details:** semantic page landmarks, labels, keyboard focus styles, and live status messages.

## How the JavaScript is organized

`src/js/main.js` is shared by each page. The `data-page` attribute tells the script which page is open. This avoids maintaining several almost-identical scripts.

- `readStorage()` and `writeStorage()` keep browser-storage handling in one place and catch storage errors.
- `getProfile()` and `getPosts()` provide default data when the visitor has not saved anything yet.
- `escapeHTML()` protects user-entered text when it is inserted into post markup.
- `makePostCard()` builds one reusable post card.
- `renderFeed()` and `renderProfilePosts()` draw the posts from the current local data.
- `publishPost()` validates the text, adds a post, saves it, and refreshes the feed.
- `handlePostAction()` toggles a like or removes a post after confirmation.
- `setupLogin()` and `setupSignup()` handle the demo forms without saving passwords.
- `setupProfileEditor()` opens the edit form and saves profile changes.
- `setupClearData()` removes the app's saved keys after confirmation.
- `start()` wires up the page controls after the document is ready.

Comments in the JavaScript explain the reasoning behind these decisions and the limitations of the prototype.

## Privacy notes (please read)

This is a **demonstration, not a secure social network**.

- The app contains no code that sends posts or profile data to a remote server.
- It does not load third-party analytics, ad pixels, remote fonts, CSS frameworks, or APIs.
- Demo posts and profile details use `localStorage`, which stays in the browser profile for this origin. It is not encrypted and can be read by scripts running on the same origin.
- Login is not real authentication. There is no password verification, account recovery, server session, or multi-user service.
- The app cannot stop browser extensions, screenshots, someone with access to the device, or external AI systems from seeing content shared with them.
- For a real public product, use a reviewed authentication and data architecture, a security audit, a clear privacy policy, and appropriate server-side protections.

## Student walkthrough / defense notes

**Why Vanilla JavaScript?** It keeps the moving parts visible and makes it easier to explain how events, data, and the DOM work without a framework hiding the steps.

**Why localStorage?** It gives the prototype a simple way to remember demo posts between refreshes without adding a backend. The trade-off is that it is not suitable for secrets or production authentication.

**Why render posts from stored data?** The data is the source of truth. After a post or like changes, rendering the list again keeps the screen consistent with what is saved.

**Why escape post text?** People can type characters that look like HTML. Escaping them makes the browser display those characters as text instead of treating them as markup.

**Why show privacy limitations in the UI?** Privacy claims should be specific and honest. The interface explains what the prototype does and does not protect instead of promising that AI tracking is impossible.

## Suggested manual checks

1. Open the feed and refresh. Sample posts should remain available.
2. Publish a short note, refresh, and confirm it is still present.
3. Like a post and toggle it back.
4. Open My Profile, edit the display name and bio, and save.
5. Create a demo profile through Signup, then log in using a username.
6. Open Privacy Room and clear the local data after confirming.
7. Test at desktop and mobile widths.
8. Use the keyboard to tab through controls and check that focus remains visible.
